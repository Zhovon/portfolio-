'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { useState, useEffect } from 'react'
import { Rocket, Zap, Layers, Cpu, Command, Terminal } from 'lucide-react'
import { usePathname } from 'next/navigation'
import { useUISound } from '@/hooks/useUISound'

const NAV_ITEMS = [
    { id: 'hero', label: 'Launch', icon: Rocket },
    { id: 'warp', label: 'Velocity', icon: Zap },
    { id: 'about', label: 'Identity', icon: Cpu },
    { id: 'dive', label: 'Discovery', icon: Command },
    { id: 'works', label: 'Artifacts', icon: Layers },
    { id: 'meta', label: 'Competence', icon: Cpu },
    { id: 'core', label: 'Engine', icon: Zap },
    { id: 'terminal', label: 'Terminal', icon: Terminal },
]

export function NexusNav() {
    const { playHover, playClick } = useUISound()
    const [activeSegment, setActiveSegment] = useState('hero')
    const [isHovered, setIsHovered] = useState<string | null>(null)
    const pathname = usePathname()
    const [isVisible, setIsVisible] = useState(false)

    useEffect(() => {
        setIsVisible(pathname === '/')
    }, [pathname])

    useEffect(() => {
        if (!isVisible) return

        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        setActiveSegment(entry.target.id)
                    }
                })
            },
            { threshold: 0, rootMargin: "-45% 0px -45% 0px" }
        )

        const observeElements = () => {
            const elements = NAV_ITEMS.map(item => document.getElementById(item.id))
            const allFound = elements.every(el => el !== null)

            if (allFound) {
                elements.forEach(el => observer.observe(el!))
                return true
            }
            return false
        }

        // Try immediately
        if (!observeElements()) {
            // Retry a few times if not found immediately (race condition fix)
            const interval = setInterval(() => {
                if (observeElements()) {
                    clearInterval(interval)
                }
            }, 100)

            // Stop trying after 2 seconds to prevent infinite loop
            setTimeout(() => clearInterval(interval), 2000)
        }

        return () => observer.disconnect()
    }, [isVisible])

    const scrollTo = (id: string) => {
        playClick()
        const el = document.getElementById(id)
        if (el) {
            el.scrollIntoView({ behavior: 'smooth' })
        }
    }

    if (!isVisible) return null

    return (
        <div className="fixed right-8 top-1/2 -translate-y-1/2 z-[100] hidden lg:flex flex-col gap-4">
            {NAV_ITEMS.map((item) => {
                const Icon = item.icon
                const isActive = activeSegment === item.id

                return (
                    <div
                        key={item.id}
                        className="relative flex items-center justify-end group"
                        onMouseEnter={() => {
                            setIsHovered(item.id)
                            playHover()
                        }}
                        onMouseLeave={() => setIsHovered(null)}
                    >
                        <AnimatePresence>
                            {isHovered === item.id && (
                                <motion.div
                                    initial={{ opacity: 0, x: 20, scale: 0.8 }}
                                    animate={{ opacity: 1, x: 0, scale: 1 }}
                                    exit={{ opacity: 0, x: 20, scale: 0.8 }}
                                    className="absolute right-14 px-4 py-2 rounded-full glass-panel border-white/10 text-[10px] font-black uppercase tracking-[0.3em] text-white whitespace-nowrap pointer-events-none"
                                >
                                    {item.label}
                                </motion.div>
                            )}
                        </AnimatePresence>

                        <button
                            onClick={() => scrollTo(item.id)}
                            className={`relative w-10 h-10 rounded-full flex items-center justify-center transition-all duration-500 border ${isActive
                                ? 'bg-white border-white scale-110 shadow-[0_0_20px_rgba(168,85,247,0.5)]'
                                : 'bg-black/20 backdrop-blur-md border-white/10 hover:border-white/40'
                                }`}
                        >
                            <Icon className={`w-4 h-4 transition-colors duration-500 ${isActive ? 'text-black' : 'text-gray-500 group-hover:text-white'
                                }`} />

                            {isActive && (
                                <motion.div
                                    layoutId="active-glow"
                                    className="absolute -inset-2 rounded-full bg-purple-500/20 blur-md -z-10"
                                />
                            )}
                        </button>
                    </div>
                )
            })}
        </div>
    )
}
